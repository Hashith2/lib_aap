package com.example.bookcave.profile;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.bookcave.R;

public class Favourites extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favourites);
    }
}
